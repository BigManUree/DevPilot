# 多 Agent 系统设计

## 1. 总体模式

采用 Supervisor 主控 Agent + 专业子 Agent 的分层架构。执行采用串行、并行和混合调度。统一上下文中心、消息总线、任务管理、权限系统和验证引擎。

## 2. Supervisor 职责

- 意图识别。
- 缺失信息判断。
- 上下文收集。
- 任务规划与拆分。
- Agent 能力匹配。
- 依赖和并行关系编排。
- 执行过程监控。
- 失败处理和有限重规划。
- 结果汇总。
- 任务完成状态判定。

## 3. 专业 Agent 类型

- Project Analyzer
- Environment Agent
- Dependency Agent
- Service Analyzer
- Config Agent
- Execution Agent
- Diagnostic Agent
- Repair Agent
- Code Analysis Agent
- Refactoring Agent
- Test Agent
- Git Agent
- Database Agent
- Validation Agent
- Custom Agent

## 4. Agent 注册信息

Agent 至少声明：
- agent_id、名称、类型、版本、来源。
- 职责和描述。
- 能力列表。
- 输入输出 Schema。
- 支持项目类型。
- 可用工具。
- 所需权限。
- 模型配置。
- 资源限制。
- 记忆范围。
- 并发限制。
- 健康状态。

## 5. 调度机制

根据任务类型、能力匹配、负载、优先级、工具可用性和权限范围分配 Agent。独立任务可并行；存在数据依赖或文件冲突时串行。对同一文件的并发写入必须使用锁、工作副本或冲突检测机制。

## 6. 任务生命周期

Pending → Preparing → Running → Paused / Waiting Approval / Waiting Input → Completed / Failed / Cancelled。

检查点保存任务计划版本、已完成子任务、中间结果、Agent 状态、工具调用记录和关键输出。恢复前重新检查项目状态、配置版本、权限和已完成操作，防止重复执行。

## 7. 验证机制

规则验证与独立 Validation Agent 结合。验证状态：
- PASSED
- FAILED
- PARTIAL
- BLOCKED
- UNKNOWN

只有满足任务完成条件且验证为 PASSED，才能标记成功。PARTIAL、BLOCKED、UNKNOWN 不得自动视为成功。

## 8. 记忆系统

采用分层记忆：
- 全局记忆。
- 项目记忆。
- 任务记忆。
- Agent 专属记忆。
- 短期上下文。

记忆支持混合检索、自动提取、质量控制、冲突检测、版本治理、备份恢复、权限隔离和数据隐私。不同项目之间默认隔离；跨项目共享必须显式授权。

## 9. Agent 可观测性

记录任务、消息、工具调用、模型调用、Token、耗时、错误、验证和资源使用。统一链路标识 project_id、task_id、agent_id、execution_id、tool_call_id、trace_id。

## 10. Agent 安全边界

Agent 只能提出工具调用请求。核心执行引擎负责权限校验和实际操作。Agent 不得绕过工具网关、扩展自身权限或隐式访问其他项目数据。
