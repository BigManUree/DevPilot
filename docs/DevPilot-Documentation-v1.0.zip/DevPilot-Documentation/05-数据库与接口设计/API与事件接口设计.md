# API 与事件接口设计

## 1. API 设计原则

- REST 用于业务资源管理和显式操作。
- WebSocket 用于实时事件、日志和状态推送。
- API 版本化，例如 `/api/v1`。
- 请求和响应使用统一错误结构。
- 所有写操作检查身份、权限、资源范围和输入 Schema。
- 不将任意命令执行接口暴露给不可信前端或插件。

## 2. REST 资源建议

### 项目
- `GET /api/v1/projects`
- `POST /api/v1/projects/import`
- `GET /api/v1/projects/:projectId`
- `PATCH /api/v1/projects/:projectId`
- `DELETE /api/v1/projects/:projectId`（默认仅删除 DevPilot 记录）
- `POST /api/v1/projects/:projectId/analyze`

### 服务与运行
- `GET /api/v1/projects/:projectId/services`
- `POST /api/v1/projects/:projectId/services`
- `POST /api/v1/services/:serviceId/start`
- `POST /api/v1/services/:serviceId/stop`
- `POST /api/v1/services/:serviceId/restart`
- `GET /api/v1/runtime/sessions`

### 任务与 Agent
- `POST /api/v1/tasks`
- `GET /api/v1/tasks`
- `GET /api/v1/tasks/:taskId`
- `POST /api/v1/tasks/:taskId/pause`
- `POST /api/v1/tasks/:taskId/resume`
- `POST /api/v1/tasks/:taskId/cancel`
- `GET /api/v1/agents`
- `GET /api/v1/agents/:agentId`

### 审批与权限
- `GET /api/v1/approvals`
- `POST /api/v1/approvals/:approvalId/approve`
- `POST /api/v1/approvals/:approvalId/reject`
- `GET /api/v1/permissions`

### 日志与诊断
- `GET /api/v1/logs`
- `GET /api/v1/traces/:traceId`
- `POST /api/v1/diagnostics`

### 配置、Git、插件、备份
分别建立 `/configs`、`/git`、`/plugins`、`/backups`、`/settings` 资源域。

## 3. WebSocket 事件

建议事件：
- `project.updated`
- `service.status.changed`
- `runtime.log`
- `task.status.changed`
- `task.progress`
- `agent.status.changed`
- `agent.message`
- `tool.call.started`
- `tool.call.completed`
- `approval.required`
- `notification.created`
- `system.health.changed`

## 4. 统一事件结构

```json
{
  "event_id": "uuid",
  "event_type": "task.status.changed",
  "timestamp": "ISO-8601",
  "source_module": "task-manager",
  "project_id": "optional",
  "task_id": "optional",
  "agent_id": "optional",
  "trace_id": "uuid",
  "severity": "info",
  "payload": {}
}
```

## 5. 统一错误结构

```json
{
  "error": {
    "code": "PERMISSION_DENIED",
    "message": "操作未获授权",
    "details": {},
    "trace_id": "uuid"
  }
}
```

## 6. 插件接口

插件必须声明 Manifest、版本、能力、输入输出 Schema、权限需求、依赖和生命周期钩子。插件调用统一经 Plugin Runtime 和 Tool Gateway。接口需版本兼容检查和超时限制。

## 7. MCP 与第三方集成

可通过适配层支持 MCP 等标准协议，但外部工具能力仍映射到 DevPilot 的权限模型。协议支持不等于自动授予权限。
